# troubleshooting-how-to-activate-deactivate-users-via-api

> Source: https://clockify.me/help/troubleshooting/how-to-activate-deactivate-users-via-api

How to activate/deactivate users via API
1 min read
To activate or deactivate a user, use the following API call:
Endpoint:
In the request body, specify the status (active
or inactive
) to update the user’s status.
Was this article helpful?
Thank you! If you’d like a member of our support team to respond to you, please drop us a note at support@clockify.me