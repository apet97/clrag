# administration-change-mail-address

> Source: https://clockify.me/help/administration/change-mail-address

Change email address
You can update your email address associated with your CAKE.com Account on the Manage CAKE.com Account page, available in your Profile settings.
To do this:
- Click on your profile icon in the upper right corner in your Clockify app
- Choose the Manage CAKE.com Account button in the Profile settings
- Or choose My profile and click the Manage CAKE.com Account button on My profile screen
You’ll be redirected to the CAKE.com Account management page, where you can make the necessary changes.
For more details on this process, refer to the Profile settings article in the CAKE.com Help Center.