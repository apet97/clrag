# wp-content-uploads-2020-11-time-import-example-file-csv

> Source: https://clockify.me/help/wp-content/uploads/2020/11/time-import-example-file.csv

Project,Client,Description,Task,Email,Tags,Billable,Start Date,Start Time,Duration (h)
PTO,Sol-Tech,Time off,Vacation,james.white@gmail.com,,No,08/31/2019,9:00 AM,8:00
GS-100 Administration,Global Solutions,Feature development,Development,dale.the.knight@gmail.com,,Yes,08/31/2019,9:00 AM,8:00
CT-200 Banking app,California Tech,Troubleshooting,Support,ethel.rose.parker@gmail.com,,Yes,08/30/2019,4:00 PM,1:00
CT-200 Banking app,California Tech,Wireframing,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/30/2019,3:00 PM,2:00
GS-100 Administration,Global Solutions,Answering tickets,Support,ethel.rose.parker@gmail.com,€,Yes,08/30/2019,2:00 PM,2:00
Office work,Sol-Tech,Paperwork,Administration,james.white@gmail.com,"invoiced, Epic",No,08/30/2019,1:00 PM,1:00
CT-300 Web portal,California Tech,Bug fixing,Development,jake.touchstone.dev@gmail.com,,Yes,08/30/2019,1:00 PM,4:00
UE-100 Administration,United Express,Interface,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/30/2019,12:00 PM,3:00
CT-200 Banking app,California Tech,Answering tickets,Support,james.white@gmail.com,,Yes,08/30/2019,12:00 PM,1:00
GS-100 Administration,Global Solutions,Answering tickets,Support,james.white@gmail.com,,Yes,08/30/2019,11:00 AM,1:00
UE-100 Administration,United Express,Bug fixing,Development,dale.the.knight@gmail.com,,Yes,08/30/2019,9:00 AM,8:00
CT-200 Banking app,California Tech,Feature development,Development,jake.touchstone.dev@gmail.com,,Yes,08/30/2019,9:00 AM,4:00
MI-300 Web portal,Marvel Inc,Illustrations,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/30/2019,9:00 AM,3:00
Office work,Sol-Tech,Taxes,Accounting,ethel.rose.parker@gmail.com,,No,08/30/2019,9:00 AM,5:00
UE-100 Administration,United Express,Troubleshooting,Support,james.white@gmail.com,,Yes,08/30/2019,9:00 AM,2:00
UE-100 Administration,United Express,Answering tickets,Support,james.white@gmail.com,,Yes,08/29/2019,5:00 PM,3:00
GS-100 Administration,Global Solutions,Troubleshooting,Support,james.white@gmail.com,,Yes,08/29/2019,3:00 PM,2:00
GS-100 Administration,Global Solutions,Troubleshooting,Support,ethel.rose.parker@gmail.com,€,Yes,08/29/2019,2:00 PM,3:00
CT-200 Banking app,California Tech,Answering tickets,Support,james.white@gmail.com,,Yes,08/29/2019,2:00 PM,1:00
MI-200 Web app,Marvel Inc,Wireframing,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/29/2019,1:00 PM,4:00
CT-200 Banking app,California Tech,Troubleshooting,Support,ethel.rose.parker@gmail.com,,Yes,08/29/2019,10:00 AM,4:00
PTO,Sol-Tech,Time off,Vacation,dale.the.knight@gmail.com,,No,08/29/2019,9:00 AM,8:00
GS-100 Administration,Global Solutions,Bug fixing,Development,jake.touchstone.dev@gmail.com,,Yes,08/29/2019,9:00 AM,8:00
CT-300 Web portal,California Tech,Interface,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/29/2019,9:00 AM,4:00
Office work,Sol-Tech,Processing payroll,Accounting,ethel.rose.parker@gmail.com,,No,08/29/2019,9:00 AM,1:00
Office work,Sol-Tech,Legal,Administration,james.white@gmail.com,,No,08/29/2019,9:00 AM,2:00
CT-300 Web portal,California Tech,Feature development,Development,jake.touchstone.dev@gmail.com,,Yes,08/28/2019,5:00 PM,4:00
GS-100 Administration,Global Solutions,Wireframing,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/28/2019,1:00 PM,4:00
CT-200 Banking app,California Tech,Troubleshooting,Support,james.white@gmail.com,,Yes,08/28/2019,1:00 PM,4:00
CT-300 Web portal,California Tech,Troubleshooting,Support,ethel.rose.parker@gmail.com,,Yes,08/28/2019,12:00 PM,5:00
PTO,Sol-Tech,Time off,Vacation,dale.the.knight@gmail.com,,No,08/28/2019,9:00 AM,8:00
MI-200 Web app,Marvel Inc,Feature development,Development,jake.touchstone.dev@gmail.com,,Yes,08/28/2019,9:00 AM,8:00
CT-300 Web portal,California Tech,Interface,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/28/2019,9:00 AM,4:00
GS-100 Administration,Global Solutions,Answering tickets,Support,ethel.rose.parker@gmail.com,€,Yes,08/28/2019,9:00 AM,3:00
GS-100 Administration,Global Solutions,Answering tickets,Support,james.white@gmail.com,,Yes,08/28/2019,9:00 AM,4:00
UE-100 Administration,United Express,Troubleshooting,Support,james.white@gmail.com,,Yes,08/27/2019,5:00 PM,1:00
CT-300 Web portal,California Tech,Answering tickets,Support,ethel.rose.parker@gmail.com,,Yes,08/27/2019,2:00 PM,3:00
MI-300 Web portal,Marvel Inc,Bug fixing,Development,jake.touchstone.dev@gmail.com,,Yes,08/27/2019,1:00 PM,2:00
GS-100 Administration,Global Solutions,Answering tickets,Support,ethel.rose.parker@gmail.com,€,Yes,08/27/2019,1:00 PM,1:00
CT-200 Banking app,California Tech,Answering tickets,Support,james.white@gmail.com,,Yes,08/27/2019,1:00 PM,4:00
UE-100 Administration,United Express,Troubleshooting,Support,james.white@gmail.com,,Yes,08/27/2019,12:00 PM,1:00
CT-200 Banking app,California Tech,Troubleshooting,Support,ethel.rose.parker@gmail.com,,Yes,08/27/2019,11:00 AM,2:00
CT-300 Web portal,California Tech,Database optimization,Development,jake.touchstone.dev@gmail.com,,Yes,08/27/2019,9:00 AM,4:00
CT-200 Banking app,California Tech,Wireframing,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/27/2019,9:00 AM,8:00
Office work,Sol-Tech,Processing payroll,Accounting,ethel.rose.parker@gmail.com,,No,08/27/2019,9:00 AM,2:00
Office work,Sol-Tech,Paperwork,Administration,james.white@gmail.com,,No,08/27/2019,9:00 AM,3:00
UE-100 Administration,United Express,Answering tickets,Support,james.white@gmail.com,,Yes,08/26/2019,2:00 PM,1:00
CT-300 Web portal,California Tech,Answering tickets,Support,ethel.rose.parker@gmail.com,,Yes,08/26/2019,12:00 PM,4:00
GS-100 Administration,Global Solutions,Troubleshooting,Support,james.white@gmail.com,,Yes,08/26/2019,12:00 PM,2:00
CT-200 Banking app,California Tech,Troubleshooting,Support,james.white@gmail.com,,Yes,08/26/2019,10:00 AM,2:00
Office work,Sol-Tech,Paperwork,Administration,james.white@gmail.com,,No,08/26/2019,9:44 AM,0:16
PTO,Sol-Tech,Time off,Sick leave,jake.touchstone.dev@gmail.com,,No,08/26/2019,9:00 AM,8:00
CT-200 Banking app,California Tech,Interface,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/26/2019,9:00 AM,8:00
Office work,Sol-Tech,Taxes,Accounting,ethel.rose.parker@gmail.com,,No,08/26/2019,9:00 AM,3:00
Office work,Sol-Tech,Paperwork,Administration,james.white@gmail.com,,No,08/26/2019,9:00 AM,0:44
MI-200 Web app,Marvel Inc,Feature development,Development,dale.the.knight@gmail.com,,Yes,08/25/2019,12:00 PM,6:00
GS-100 Administration,Global Solutions,Bug fixing,Development,dale.the.knight@gmail.com,,Yes,08/25/2019,9:00 AM,3:00
GS-100 Administration,Global Solutions,Feature development,Development,dale.the.knight@gmail.com,,Yes,08/24/2019,1:00 PM,3:00
CT-200 Banking app,California Tech,Bug fixing,Development,dale.the.knight@gmail.com,,Yes,08/24/2019,9:00 AM,4:00
GS-100 Administration,Global Solutions,Feature development,Development,dale.the.knight@gmail.com,,Yes,08/23/2019,2:00 PM,3:00
GS-100 Administration,Global Solutions,Wireframing,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/23/2019,2:00 PM,3:00
CT-300 Web portal,California Tech,Troubleshooting,Support,ethel.rose.parker@gmail.com,,Yes,08/23/2019,2:00 PM,3:00
CT-200 Banking app,California Tech,Feature development,Development,jake.touchstone.dev@gmail.com,,Yes,08/23/2019,1:04 PM,3:56
GS-100 Administration,Global Solutions,Troubleshooting,Support,james.white@gmail.com,,Yes,08/23/2019,1:00 PM,2:00
CT-200 Banking app,California Tech,Answering tickets,Support,james.white@gmail.com,,Yes,08/23/2019,12:00 PM,1:00
GS-100 Administration,Global Solutions,Troubleshooting,Support,ethel.rose.parker@gmail.com,€,Yes,08/23/2019,10:00 AM,4:00
CT-300 Web portal,California Tech,Bug fixing,Development,jake.touchstone.dev@gmail.com,,Yes,08/23/2019,9:04 AM,4:00
CT-300 Web portal,California Tech,Bug fixing,Development,dale.the.knight@gmail.com,,Yes,08/23/2019,9:00 AM,5:00
CT-200 Banking app,California Tech,Feature development,Development,jake.touchstone.dev@gmail.com,,Yes,08/23/2019,9:00 AM,0:04
CT-300 Web portal,California Tech,Illustrations,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/23/2019,9:00 AM,5:00
Office work,Sol-Tech,Invoicing,Accounting,ethel.rose.parker@gmail.com,,No,08/23/2019,9:00 AM,1:00
Office work,Sol-Tech,Legal,Administration,james.white@gmail.com,,No,08/23/2019,9:00 AM,3:00
CT-200 Banking app,California Tech,Answering tickets,Support,ethel.rose.parker@gmail.com,,Yes,08/22/2019,3:00 PM,3:00
PTO,Sol-Tech,Time off,Vacation,james.white@gmail.com,,No,08/22/2019,3:00 PM,8:00
MI-200 Web app,Marvel Inc,Feature development,Development,dale.the.knight@gmail.com,,Yes,08/22/2019,2:00 PM,3:00
GS-100 Administration,Global Solutions,Feature development,Development,jake.touchstone.dev@gmail.com,,Yes,08/22/2019,1:00 PM,4:00
CT-300 Web portal,California Tech,Troubleshooting,Support,ethel.rose.parker@gmail.com,,Yes,08/22/2019,11:00 AM,4:00
CT-300 Web portal,California Tech,Feature development,Development,dale.the.knight@gmail.com,,Yes,08/22/2019,9:00 AM,5:00
MI-200 Web app,Marvel Inc,Bug fixing,Development,jake.touchstone.dev@gmail.com,,Yes,08/22/2019,9:00 AM,4:00
CT-300 Web portal,California Tech,Wireframing,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/22/2019,9:00 AM,8:00
Office work,Sol-Tech,Processing payroll,Accounting,ethel.rose.parker@gmail.com,,No,08/22/2019,9:00 AM,2:00
UE-100 Administration,United Express,Troubleshooting,Support,james.white@gmail.com,,Yes,08/21/2019,4:00 PM,1:00
GS-100 Administration,Global Solutions,Answering tickets,Support,james.white@gmail.com,,Yes,08/21/2019,3:00 PM,1:00
MI-300 Web portal,Marvel Inc,Bug fixing,Development,jake.touchstone.dev@gmail.com,,Yes,08/21/2019,2:00 PM,3:00
CT-300 Web portal,California Tech,Troubleshooting,Support,ethel.rose.parker@gmail.com,,Yes,08/21/2019,2:00 PM,3:00
MI-300 Web portal,Marvel Inc,Database optimization,Development,dale.the.knight@gmail.com,,Yes,08/21/2019,1:00 PM,4:00
CT-200 Banking app,California Tech,Answering tickets,Support,ethel.rose.parker@gmail.com,,Yes,08/21/2019,1:00 PM,1:00
CT-200 Banking app,California Tech,Answering tickets,Support,james.white@gmail.com,,Yes,08/21/2019,1:00 PM,2:00
CT-200 Banking app,California Tech,Interface,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/21/2019,11:00 AM,6:00
UE-100 Administration,United Express,Wireframing,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/21/2019,10:00 AM,1:00
CT-200 Banking app,California Tech,Bug fixing,Development,dale.the.knight@gmail.com,,Yes,08/21/2019,9:00 AM,4:00
UE-100 Administration,United Express,Bug fixing,Development,jake.touchstone.dev@gmail.com,,Yes,08/21/2019,9:00 AM,5:00
MI-300 Web portal,Marvel Inc,Illustrations,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/21/2019,9:00 AM,1:00
Office work,Sol-Tech,Invoicing,Accounting,ethel.rose.parker@gmail.com,,No,08/21/2019,9:00 AM,4:00
Office work,Sol-Tech,Paperwork,Administration,james.white@gmail.com,,No,08/21/2019,9:00 AM,4:00
GS-100 Administration,Global Solutions,Troubleshooting,Support,james.white@gmail.com,,Yes,08/20/2019,4:00 PM,2:00
UE-100 Administration,United Express,Answering tickets,Support,james.white@gmail.com,,Yes,08/20/2019,2:00 PM,2:00
UE-100 Administration,United Express,Interface,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/20/2019,11:00 AM,6:00
MI-200 Web app,Marvel Inc,Wireframing,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/20/2019,10:00 AM,1:00
MI-300 Web portal,Marvel Inc,Database optimization,Development,jake.touchstone.dev@gmail.com,,Yes,08/20/2019,9:00 AM,8:00
GS-100 Administration,Global Solutions,Illustrations,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/20/2019,9:00 AM,1:00
PTO,Sol-Tech,Time off,Vacation,ethel.rose.parker@gmail.com,,No,08/20/2019,9:00 AM,8:00
CT-200 Banking app,California Tech,Troubleshooting,Support,james.white@gmail.com,,Yes,08/20/2019,9:00 AM,5:00
MI-200 Web app,Marvel Inc,Answering tickets,Support,james.white@gmail.com,,Yes,08/19/2019,5:00 PM,1:00
UE-100 Administration,United Express,Troubleshooting,Support,james.white@gmail.com,,Yes,08/19/2019,1:00 PM,4:00
MI-300 Web portal,Marvel Inc,Wireframing,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/19/2019,11:00 AM,6:00
GS-100 Administration,Global Solutions,Troubleshooting,Support,james.white@gmail.com,,Yes,08/19/2019,11:00 AM,2:00
CT-300 Web portal,California Tech,Interface,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/19/2019,10:00 AM,1:00
CT-200 Banking app,California Tech,Answering tickets,Support,james.white@gmail.com,,Yes,08/19/2019,10:00 AM,1:00
MI-300 Web portal,Marvel Inc,Bug fixing,Development,jake.touchstone.dev@gmail.com,,Yes,08/19/2019,9:00 AM,8:00
CT-200 Banking app,California Tech,Illustrations,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/19/2019,9:00 AM,1:00
PTO,Sol-Tech,Time off,Vacation,ethel.rose.parker@gmail.com,,No,08/19/2019,9:00 AM,8:00
Office work,Sol-Tech,Legal,Administration,james.white@gmail.com,,No,08/19/2019,9:00 AM,1:00
CT-300 Web portal,California Tech,Feature development,Development,dale.the.knight@gmail.com,,Yes,08/17/2019,3:00 PM,2:00
MI-300 Web portal,Marvel Inc,Bug fixing,Development,dale.the.knight@gmail.com,,Yes,08/17/2019,12:00 PM,3:00
MI-200 Web app,Marvel Inc,Database optimization,Development,dale.the.knight@gmail.com,,Yes,08/17/2019,9:03 AM,2:57
MI-200 Web app,Marvel Inc,Database optimization,Development,dale.the.knight@gmail.com,,Yes,08/17/2019,9:00 AM,0:03
CT-300 Web portal,California Tech,Feature development,Development,jake.touchstone.dev@gmail.com,,Yes,08/16/2019,4:00 PM,1:00
CT-200 Banking app,California Tech,Answering tickets,Support,james.white@gmail.com,,Yes,08/16/2019,4:00 PM,2:00
UE-100 Administration,United Express,Wireframing,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/16/2019,3:00 PM,2:00
MI-300 Web portal,Marvel Inc,Answering tickets,Support,james.white@gmail.com,,Yes,08/16/2019,3:00 PM,1:00
MI-300 Web portal,Marvel Inc,Database optimization,Development,dale.the.knight@gmail.com,,Yes,08/16/2019,1:00 PM,4:00
GS-100 Administration,Global Solutions,Feature development,Development,jake.touchstone.dev@gmail.com,,Yes,08/16/2019,1:00 PM,3:00
GS-100 Administration,Global Solutions,Answering tickets,Support,ethel.rose.parker@gmail.com,€,Yes,08/16/2019,1:00 PM,3:00
UE-100 Administration,United Express,Troubleshooting,Support,james.white@gmail.com,,Yes,08/16/2019,12:00 PM,3:00
MI-200 Web app,Marvel Inc,Bug fixing,Development,jake.touchstone.dev@gmail.com,,Yes,08/16/2019,10:00 AM,3:00
GS-100 Administration,Global Solutions,Troubleshooting,Support,james.white@gmail.com,,Yes,08/16/2019,10:00 AM,2:00
MI-200 Web app,Marvel Inc,Feature development,Development,dale.the.knight@gmail.com,,Yes,08/16/2019,9:00 AM,4:00
MI-300 Web portal,Marvel Inc,Database optimization,Development,jake.touchstone.dev@gmail.com,,Yes,08/16/2019,9:00 AM,1:00
MI-300 Web portal,Marvel Inc,Illustrations,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/16/2019,9:00 AM,6:00
CT-300 Web portal,California Tech,Answering tickets,Support,ethel.rose.parker@gmail.com,,Yes,08/16/2019,9:00 AM,4:00
Office work,Sol-Tech,Legal,Administration,james.white@gmail.com,,No,08/16/2019,9:00 AM,1:00
CT-300 Web portal,California Tech,Feature development,Development,jake.touchstone.dev@gmail.com,,Yes,08/15/2019,2:00 PM,4:00
MI-300 Web portal,Marvel Inc,Wireframing,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/15/2019,1:00 PM,4:00
CT-300 Web portal,California Tech,Troubleshooting,Support,ethel.rose.parker@gmail.com,,Yes,08/15/2019,1:00 PM,4:00
GS-100 Administration,Global Solutions,Troubleshooting,Support,james.white@gmail.com,,Yes,08/15/2019,12:00 PM,5:00
MI-200 Web app,Marvel Inc,Answering tickets,Support,james.white@gmail.com,,Yes,08/15/2019,10:00 AM,2:00
MI-200 Web app,Marvel Inc,Bug fixing,Development,dale.the.knight@gmail.com,,Yes,08/15/2019,9:00 AM,8:00
MI-200 Web app,Marvel Inc,Feature development,Development,jake.touchstone.dev@gmail.com,,Yes,08/15/2019,9:00 AM,5:00
MI-200 Web app,Marvel Inc,Wireframing,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/15/2019,9:00 AM,4:00
Office work,Sol-Tech,Processing payroll,Accounting,ethel.rose.parker@gmail.com,,No,08/15/2019,9:00 AM,4:00
MI-300 Web portal,Marvel Inc,Answering tickets,Support,james.white@gmail.com,,Yes,08/15/2019,9:00 AM,1:00
MI-200 Web app,Marvel Inc,Bug fixing,Development,jake.touchstone.dev@gmail.com,,Yes,08/14/2019,2:00 PM,2:00
GS-100 Administration,Global Solutions,Interface,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/14/2019,1:00 PM,4:00
UE-100 Administration,United Express,Answering tickets,Support,james.white@gmail.com,,Yes,08/14/2019,12:00 PM,5:00
GS-100 Administration,Global Solutions,Answering tickets,Support,ethel.rose.parker@gmail.com,€,Yes,08/14/2019,10:00 AM,5:00
MI-300 Web portal,Marvel Inc,Troubleshooting,Support,james.white@gmail.com,,Yes,08/14/2019,10:00 AM,2:00
MI-200 Web app,Marvel Inc,Feature development,Development,dale.the.knight@gmail.com,,Yes,08/14/2019,9:00 AM,8:00
GS-100 Administration,Global Solutions,Bug fixing,Development,jake.touchstone.dev@gmail.com,,Yes,08/14/2019,9:00 AM,5:00
CT-300 Web portal,California Tech,Interface,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/14/2019,9:00 AM,4:00
CT-200 Banking app,California Tech,Troubleshooting,Support,ethel.rose.parker@gmail.com,,Yes,08/14/2019,9:00 AM,1:00
MI-200 Web app,Marvel Inc,Troubleshooting,Support,james.white@gmail.com,,Yes,08/14/2019,9:00 AM,1:00
MI-300 Web portal,Marvel Inc,Feature development,Development,jake.touchstone.dev@gmail.com,,Yes,08/13/2019,3:00 PM,3:00
MI-200 Web app,Marvel Inc,Feature development,Development,jake.touchstone.dev@gmail.com,,Yes,08/13/2019,12:00 PM,3:00
CT-300 Web portal,California Tech,Answering tickets,Support,ethel.rose.parker@gmail.com,,Yes,08/13/2019,12:00 PM,2:00
MI-300 Web portal,Marvel Inc,Answering tickets,Support,james.white@gmail.com,,Yes,08/13/2019,12:00 PM,3:00
Office work,Sol-Tech,Paperwork,Administration,james.white@gmail.com,,No,08/13/2019,10:00 AM,2:00
CT-300 Web portal,California Tech,Bug fixing,Development,jake.touchstone.dev@gmail.com,,Yes,08/13/2019,9:00 AM,3:00
PTO,Sol-Tech,Time off,Vacation,yvonne.gardner.ivy@gmail.com,,No,08/13/2019,9:00 AM,8:00
Office work,Sol-Tech,Invoicing,Accounting,ethel.rose.parker@gmail.com,,No,08/13/2019,9:00 AM,3:00
GS-100 Administration,Global Solutions,Troubleshooting,Support,james.white@gmail.com,,Yes,08/13/2019,9:00 AM,1:00
MI-300 Web portal,Marvel Inc,Bug fixing,Development,jake.touchstone.dev@gmail.com,,Yes,08/12/2019,5:00 PM,1:00
Office work,Sol-Tech,Taxes,Accounting,ethel.rose.parker@gmail.com,,No,08/12/2019,5:00 PM,3:00
Office work,Sol-Tech,Paperwork,Administration,james.white@gmail.com,,No,08/12/2019,3:00 PM,1:00
GS-100 Administration,Global Solutions,Answering tickets,Support,ethel.rose.parker@gmail.com,€,Yes,08/12/2019,2:00 PM,3:00
GS-100 Administration,Global Solutions,Feature development,Development,jake.touchstone.dev@gmail.com,,Yes,08/12/2019,12:00 PM,5:00
GS-100 Administration,Global Solutions,Troubleshooting,Support,james.white@gmail.com,,Yes,08/12/2019,12:00 PM,3:00
CT-300 Web portal,California Tech,Answering tickets,Support,ethel.rose.parker@gmail.com,,Yes,08/12/2019,10:00 AM,4:00
UE-100 Administration,United Express,Answering tickets,Support,james.white@gmail.com,,Yes,08/12/2019,10:00 AM,2:00
CT-200 Banking app,California Tech,Feature development,Development,jake.touchstone.dev@gmail.com,,Yes,08/12/2019,9:00 AM,3:00
PTO,Sol-Tech,Time off,Vacation,yvonne.gardner.ivy@gmail.com,,No,08/12/2019,9:00 AM,8:00
CT-200 Banking app,California Tech,Troubleshooting,Support,ethel.rose.parker@gmail.com,,Yes,08/12/2019,9:00 AM,1:00
CT-200 Banking app,California Tech,Troubleshooting,Support,james.white@gmail.com,,Yes,08/12/2019,9:00 AM,1:00
GS-100 Administration,Global Solutions,Database optimization,Development,dale.the.knight@gmail.com,,Yes,08/11/2019,2:00 PM,3:00
CT-300 Web portal,California Tech,Feature development,Development,dale.the.knight@gmail.com,,Yes,08/11/2019,9:00 AM,5:00
CT-300 Web portal,California Tech,Bug fixing,Development,dale.the.knight@gmail.com,,Yes,08/10/2019,2:00 PM,3:00
GS-100 Administration,Global Solutions,Feature development,Development,dale.the.knight@gmail.com,,Yes,08/10/2019,9:00 AM,5:00
CT-200 Banking app,California Tech,Answering tickets,Support,ethel.rose.parker@gmail.com,,Yes,08/09/2019,4:00 PM,1:00
UE-100 Administration,United Express,Database optimization,Development,jake.touchstone.dev@gmail.com,,Yes,08/09/2019,3:00 PM,1:00
MI-200 Web app,Marvel Inc,Troubleshooting,Support,james.white@gmail.com,,Yes,08/09/2019,3:00 PM,1:00
GS-100 Administration,Global Solutions,Bug fixing,Development,dale.the.knight@gmail.com,,Yes,08/09/2019,2:00 PM,3:00
UE-100 Administration,United Express,Wireframing,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/09/2019,1:00 PM,4:00
CT-300 Web portal,California Tech,Answering tickets,Support,ethel.rose.parker@gmail.com,,Yes,08/09/2019,1:00 PM,3:00
CT-200 Banking app,California Tech,Troubleshooting,Support,james.white@gmail.com,,Yes,08/09/2019,1:00 PM,2:00
MI-300 Web portal,Marvel Inc,Bug fixing,Development,jake.touchstone.dev@gmail.com,,Yes,08/09/2019,12:00 PM,3:00
MI-300 Web portal,Marvel Inc,Wireframing,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/09/2019,11:00 AM,2:00
MI-300 Web portal,Marvel Inc,Answering tickets,Support,james.white@gmail.com,,Yes,08/09/2019,10:00 AM,3:00
CT-300 Web portal,California Tech,Bug fixing,Development,dale.the.knight@gmail.com,,Yes,08/09/2019,9:00 AM,5:00
CT-300 Web portal,California Tech,Bug fixing,Development,jake.touchstone.dev@gmail.com,,Yes,08/09/2019,9:00 AM,3:00
MI-200 Web app,Marvel Inc,Illustrations,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/09/2019,9:00 AM,2:00
GS-100 Administration,Global Solutions,Troubleshooting,Support,ethel.rose.parker@gmail.com,€,Yes,08/09/2019,9:00 AM,4:00
Office work,Sol-Tech,Legal,Administration,james.white@gmail.com,,No,08/09/2019,9:00 AM,1:00
CT-200 Banking app,California Tech,Troubleshooting,Support,ethel.rose.parker@gmail.com,,Yes,08/08/2019,4:00 PM,1:00
GS-100 Administration,Global Solutions,Feature development,Development,dale.the.knight@gmail.com,,Yes,08/08/2019,2:00 PM,3:00
UE-100 Administration,United Express,Troubleshooting,Support,james.white@gmail.com,,Yes,08/08/2019,2:00 PM,3:00
CT-300 Web portal,California Tech,Feature development,Development,jake.touchstone.dev@gmail.com,,Yes,08/08/2019,1:00 PM,4:00
CT-300 Web portal,California Tech,Answering tickets,Support,ethel.rose.parker@gmail.com,,Yes,08/08/2019,1:00 PM,3:00
MI-200 Web app,Marvel Inc,Answering tickets,Support,james.white@gmail.com,,Yes,08/08/2019,1:00 PM,1:00
GS-100 Administration,Global Solutions,Database optimization,Development,jake.touchstone.dev@gmail.com,,Yes,08/08/2019,11:00 AM,2:00
CT-300 Web portal,California Tech,Bug fixing,Development,dale.the.knight@gmail.com,,Yes,08/08/2019,9:00 AM,5:00
CT-200 Banking app,California Tech,Feature development,Development,jake.touchstone.dev@gmail.com,,Yes,08/08/2019,9:00 AM,2:00
GS-100 Administration,Global Solutions,Illustrations,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/08/2019,9:00 AM,8:00
GS-100 Administration,Global Solutions,Troubleshooting,Support,ethel.rose.parker@gmail.com,€,Yes,08/08/2019,9:00 AM,4:00
GS-100 Administration,Global Solutions,Troubleshooting,Support,james.white@gmail.com,,Yes,08/08/2019,9:00 AM,4:00
GS-100 Administration,Global Solutions,Feature development,Development,dale.the.knight@gmail.com,,Yes,08/07/2019,2:00 PM,3:00
MI-300 Web portal,Marvel Inc,Bug fixing,Development,jake.touchstone.dev@gmail.com,,Yes,08/07/2019,2:00 PM,3:00
CT-300 Web portal,California Tech,Answering tickets,Support,ethel.rose.parker@gmail.com,,Yes,08/07/2019,2:00 PM,4:00
GS-100 Administration,Global Solutions,Interface,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/07/2019,1:00 PM,4:00
CT-200 Banking app,California Tech,Troubleshooting,Support,ethel.rose.parker@gmail.com,,Yes,08/07/2019,11:00 AM,3:00
Office work,Sol-Tech,Paperwork,Administration,james.white@gmail.com,,No,08/07/2019,10:05 AM,2:00
MI-300 Web portal,Marvel Inc,Answering tickets,Support,james.white@gmail.com,,Yes,08/07/2019,10:05 AM,4:00
CT-200 Banking app,California Tech,Answering tickets,Support,james.white@gmail.com,,Yes,08/07/2019,10:05 AM,0:00
CT-200 Banking app,California Tech,Answering tickets,Support,james.white@gmail.com,,Yes,08/07/2019,10:05 AM,0:00
CT-300 Web portal,California Tech,Database optimization,Development,dale.the.knight@gmail.com,,Yes,08/07/2019,9:00 AM,5:00
MI-200 Web app,Marvel Inc,Database optimization,Development,jake.touchstone.dev@gmail.com,,Yes,08/07/2019,9:00 AM,5:00
CT-300 Web portal,California Tech,Illustrations,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/07/2019,9:00 AM,4:00
Office work,Sol-Tech,Processing payroll,Accounting,ethel.rose.parker@gmail.com,,No,08/07/2019,9:00 AM,2:00
MI-300 Web portal,Marvel Inc,Answering tickets,Support,james.white@gmail.com,,Yes,08/06/2019,5:00 PM,1:00
GS-100 Administration,Global Solutions,Wireframing,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/06/2019,4:00 PM,1:00
MI-200 Web app,Marvel Inc,Feature development,Development,jake.touchstone.dev@gmail.com,,Yes,08/06/2019,2:03 PM,2:57
MI-200 Web app,Marvel Inc,Feature development,Development,jake.touchstone.dev@gmail.com,,Yes,08/06/2019,2:00 PM,0:03
UE-100 Administration,United Express,Illustrations,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/06/2019,1:00 PM,3:00
CT-300 Web portal,California Tech,Troubleshooting,Support,ethel.rose.parker@gmail.com,,Yes,08/06/2019,1:00 PM,3:00
MI-200 Web app,Marvel Inc,Trouebleshooting,Support,james.white@gmail.com,,Yes,08/06/2019,1:00 PM,4:00
GS-100 Administration,Global Solutions,Feature development,Development,jake.touchstone.dev@gmail.com,,Yes,08/06/2019,9:00 AM,5:00
MI-200 Web app,Marvel Inc,Interface,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/06/2019,9:00 AM,4:00
Office work,Sol-Tech,Invoicing,Accounting,ethel.rose.parker@gmail.com,,No,08/06/2019,9:00 AM,4:00
UE-100 Administration,United Express,Answering tickets,Support,james.white@gmail.com,,Yes,08/06/2019,9:00 AM,4:00
MI-200 Web app,Marvel Inc,Wireframing,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/05/2019,2:00 PM,3:00
Office work,Sol-Tech,Errands,Administration,james.white@gmail.com,,No,08/05/2019,2:00 PM,1:00
GS-100 Administration,Global Solutions,Bug fixing,Development,jake.touchstone.dev@gmail.com,,Yes,08/05/2019,1:00 PM,4:00
CT-200 Banking app,California Tech,Answering tickets,Support,ethel.rose.parker@gmail.com,,Yes,08/05/2019,1:00 PM,4:00
MI-300 Web portal,Marvel Inc,Troubleshooting,Support,james.white@gmail.com,,Yes,08/05/2019,12:00 PM,2:00
MI-300 Web portal,Marvel Inc,Interface,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/05/2019,10:00 AM,4:00
GS-100 Administration,Global Solutions,Answering tickets,Support,james.white@gmail.com,,Yes,08/05/2019,10:00 AM,2:00
CT-200 Banking app,California Tech,Database optimization,Development,jake.touchstone.dev@gmail.com,,Yes,08/05/2019,9:00 AM,4:00
UE-100 Administration,United Express,Illustrations,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/05/2019,9:00 AM,1:00
Office work,Sol-Tech,Processing payroll,Accounting,ethel.rose.parker@gmail.com,,No,08/05/2019,9:00 AM,4:00
CT-200 Banking app,California Tech,Troubleshooting,Support,james.white@gmail.com,,Yes,08/05/2019,9:00 AM,1:00
CT-200 Banking app,California Tech,Bug fixing,Development,dale.the.knight@gmail.com,,Yes,08/03/2019,9:00 AM,8:00
Office work,Sol-Tech,Invoicing,Accounting,ethel.rose.parker@gmail.com,invoiced,No,08/02/2019,4:00 PM,1:00
GS-100 Administration,Global Solutions,Answering tickets,Support,james.white@gmail.com,,Yes,08/02/2019,2:03 PM,2:57
GS-100 Administration,Global Solutions,Answering tickets,Support,james.white@gmail.com,,Yes,08/02/2019,2:00 PM,0:03
GS-100 Administration,Global Solutions,Wireframing,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/02/2019,1:00 PM,4:00
MI-300 Web portal,Marvel Inc,Troubleshooting,Support,james.white@gmail.com,,Yes,08/02/2019,1:00 PM,1:00
CT-300 Web portal,California Tech,Troubleshooting,Support,ethel.rose.parker@gmail.com,invoiced,Yes,08/02/2019,12:00 PM,4:00
CT-200 Banking app,California Tech,Feature development,Development,dale.the.knight@gmail.com,,Yes,08/02/2019,9:00 AM,8:00
CT-300 Web portal,California Tech,Illustrations,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/02/2019,9:00 AM,4:00
GS-100 Administration,Global Solutions,Answering tickets,Support,ethel.rose.parker@gmail.com,"invoiced, €",Yes,08/02/2019,9:00 AM,3:00
UE-100 Administration,United Express,Answering tickets,Support,james.white@gmail.com,,Yes,08/02/2019,9:00 AM,4:00
CT-200 Banking app,California Tech,Answering tickets,Support,ethel.rose.parker@gmail.com,invoiced,Yes,08/01/2019,3:00 PM,2:00
CT-200 Banking app,California Tech,Database optimization,Development,jake.touchstone.dev@gmail.com,,Yes,08/01/2019,1:00 PM,4:00
GS-100 Administration,Global Solutions,Wireframing,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/01/2019,1:00 PM,4:00
GS-100 Administration,Global Solutions,Answering tickets,Support,james.white@gmail.com,,Yes,08/01/2019,1:00 PM,1:00
CT-300 Web portal,California Tech,Troubleshooting,Support,ethel.rose.parker@gmail.com,invoiced,Yes,08/01/2019,12:00 PM,3:00
CT-300 Web portal,California Tech,Wireframing,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/01/2019,11:00 AM,2:00
MI-300 Web portal,Marvel Inc,Answering tickets,Support,james.white@gmail.com,,Yes,08/01/2019,10:00 AM,3:00
CT-200 Banking app,California Tech,Database optimization,Development,dale.the.knight@gmail.com,,Yes,08/01/2019,9:00 AM,8:00
CT-300 Web portal,California Tech,Bug fixing,Development,jake.touchstone.dev@gmail.com,,Yes,08/01/2019,9:00 AM,4:00
CT-200 Banking app,California Tech,Wireframing,Design,yvonne.gardner.ivy@gmail.com,,Yes,08/01/2019,9:00 AM,2:00
GS-100 Administration,Global Solutions,Answering tickets,Support,ethel.rose.parker@gmail.com,"invoiced, €",Yes,08/01/2019,9:00 AM,3:00
Office work,Sol-Tech,Paperwork,Administration,james.white@gmail.com,,No,08/01/2019,9:00 AM,1:00
GS-100 Administration,Global Solutions,Answering tickets,Support,james.white@gmail.com,,Yes,07/31/2019,5:00 PM,3:00
MI-300 Web portal,Marvel Inc,Answering tickets,Support,james.white@gmail.com,,Yes,07/31/2019,3:00 PM,2:00
UE-100 Administration,United Express,Troubleshooting,Support,james.white@gmail.com,,Yes,07/31/2019,11:00 AM,4:00
CT-200 Banking app,California Tech,Feature development,Development,jake.touchstone.dev@gmail.com,,Yes,07/31/2019,9:00 AM,8:00
Office work,Sol-Tech,Paperwork,Administration,james.white@gmail.com,,Yes,07/31/2019,9:00 AM,2:00
MI-200 Web app,Marvel Inc,,Support,james.white@gmail.com,,Yes,07/30/2019,2:00 PM,4:00
CT-200 Banking app,California Tech,,Support,james.white@gmail.com,,Yes,07/30/2019,12:00 PM,2:00
Office work,Sol-Tech,,Administration,james.white@gmail.com,,Yes,07/30/2019,9:00 AM,3:00
MI-200 Web app,Marvel Inc,,Support,james.white@gmail.com,,Yes,07/29/2019,3:00 PM,1:00
MI-300 Web portal,Marvel Inc,,Support,james.white@gmail.com,,Yes,07/29/2019,12:00 PM,3:00
UE-100 Administration,United Express,,Support,james.white@gmail.com,,Yes,07/29/2019,10:00 AM,2:00
Office work,Sol-Tech,,Administration,james.white@gmail.com,,Yes,07/29/2019,9:00 AM,1:00
CT-200 Banking app,California Tech,,,james.white@gmail.com,,Yes,07/26/2019,1:00 PM,3:00
Office work,Sol-Tech,,,james.white@gmail.com,,Yes,07/26/2019,10:00 AM,3:00
CT-300 Web portal,California Tech,,,james.white@gmail.com,,Yes,07/26/2019,9:00 AM,1:00
CT-300 Web portal,California Tech,,,james.white@gmail.com,,Yes,07/25/2019,3:19 PM,0:00
PTO,Sol-Tech,,,james.white@gmail.com,,Yes,07/25/2019,9:00 AM,8:00
CT-300 Web portal,California Tech,,,james.white@gmail.com,,Yes,07/24/2019,1:00 PM,4:00
UE-100 Administration,United Express,,,james.white@gmail.com,,Yes,07/24/2019,9:04 AM,3:56
UE-100 Administration,United Express,,,james.white@gmail.com,,Yes,07/24/2019,9:00 AM,0:04
CT-300 Web portal,California Tech,,,james.white@gmail.com,,Yes,07/23/2019,11:00 AM,2:00
Office work,Sol-Tech,,,james.white@gmail.com,,Yes,07/23/2019,10:00 AM,1:00
CT-200 Banking app,California Tech,,,james.white@gmail.com,,Yes,07/23/2019,9:00 AM,1:00
CT-200 Banking app,California Tech,,,james.white@gmail.com,,Yes,07/22/2019,5:00 PM,0:05
Office work,Sol-Tech,,,james.white@gmail.com,,Yes,07/22/2019,4:25 PM,0:35
UE-100 Administration,United Express,,,james.white@gmail.com,,Yes,07/22/2019,11:25 AM,5:00
CT-300 Web portal,California Tech,,,james.white@gmail.com,,Yes,07/22/2019,10:20 AM,1:00
CT-200 Banking app,California Tech,,,james.white@gmail.com,,Yes,07/22/2019,9:25 AM,0:55
Office work,Sol-Tech,,,james.white@gmail.com,,Yes,07/22/2019,9:00 AM,0:25
Office work,Sol-Tech,,,james.white@gmail.com,,Yes,07/18/2019,9:40 AM,0:01
Office work,Sol-Tech,[Clockify Support] how to add team members,,james.white@gmail.com,,Yes,07/17/2019,12:49 PM,0:01
,,,,yvonne.gardner.ivy@gmail.com,,No,07/12/2019,1:23 PM,0:01
UE-100 Administration,United Express,Wireframing,,yvonne.gardner.ivy@gmail.com,,Yes,07/12/2019,12:33 PM,0:05
,,,,yvonne.gardner.ivy@gmail.com,,No,07/12/2019,10:09 AM,0:03
UE-100 Administration,United Express,Interface,,yvonne.gardner.ivy@gmail.com,,No,07/10/2019,4:14 PM,0:03
,,,,yvonne.gardner.ivy@gmail.com,,No,07/10/2019,11:30 AM,0:08
,,,,yvonne.gardner.ivy@gmail.com,,No,07/10/2019,10:10 AM,0:33
,,,,yvonne.gardner.ivy@gmail.com,,No,07/10/2019,9:53 AM,0:17
,,,,yvonne.gardner.ivy@gmail.com,,No,07/09/2019,9:35 AM,0:04
,,,,yvonne.gardner.ivy@gmail.com,,No,07/08/2019,1:33 PM,1:09
,,,,yvonne.gardner.ivy@gmail.com,,No,07/08/2019,12:16 PM,0:01
,,,,yvonne.gardner.ivy@gmail.com,,No,07/08/2019,12:02 PM,0:10
,,,,yvonne.gardner.ivy@gmail.com,,No,07/08/2019,10:49 AM,0:05
,,,,yvonne.gardner.ivy@gmail.com,,No,07/05/2019,8:35 AM,0:04
,,,,yvonne.gardner.ivy@gmail.com,,No,06/28/2019,8:16 AM,0:01
,,,,yvonne.gardner.ivy@gmail.com,,No,06/27/2019,2:49 PM,0:02
,,Illustrations,,yvonne.gardner.ivy@gmail.com,,No,06/24/2019,9:20 AM,0:17
,,Illustrations,,yvonne.gardner.ivy@gmail.com,,No,06/24/2019,8:10 AM,0:01
,,aewresrsr,,james.white@gmail.com,,No,06/19/2019,9:32 AM,0:01
,,rtydfyfgy,,james.white@gmail.com,,No,06/19/2019,8:44 AM,0:04
,,dsdsssa,,james.white@gmail.com,,No,06/07/2019,10:11 AM,0:01
,,5c5bda4fb079871c518b6f07,,james.white@gmail.com,,No,06/07/2019,9:35 AM,0:03
,,,,james.white@gmail.com,,No,06/07/2019,9:35 AM,0:01
,,Fix zapier test trigger,,james.white@gmail.com,,No,06/06/2019,2:30 PM,0:01
,,Fix zapier test trigger,,james.white@gmail.com,,No,06/06/2019,2:30 PM,0:01
,,5c5bda4fb079871c518b6f07,,james.white@gmail.com,,No,06/06/2019,2:30 PM,0:01
,,5c5bda4fb079871c518b6f07,,james.white@gmail.com,,No,06/06/2019,2:30 PM,0:01
,,Timesheet (refactoring),,james.white@gmail.com,,No,06/06/2019,2:28 PM,0:01
,,Timesheet (refactoring),,james.white@gmail.com,,No,06/06/2019,2:28 PM,0:01
,,,,james.white@gmail.com,,No,06/06/2019,2:28 PM,0:01
MI-300 Web portal,Marvel Inc,Order projects by status doesn't work (6),,james.white@gmail.com,,Yes,05/27/2019,2:40 PM,0:04
CT-200 Banking app,California Tech,4e54e,,james.white@gmail.com,,Yes,05/27/2019,2:38 PM,0:03
,,dsdsssa,,james.white@gmail.com,,No,05/27/2019,2:35 PM,0:01
CT-200 Banking app,California Tech,,,james.white@gmail.com,,Yes,05/20/2019,9:00 AM,1:00
,,,,yvonne.gardner.ivy@gmail.com,,Yes,05/17/2019,9:04 AM,0:00
,,pauiza,,james.white@gmail.com,,Yes,05/17/2019,8:35 AM,0:01
,,Lunch break,,james.white@gmail.com,,Yes,05/17/2019,8:35 AM,0:01
,,,,james.white@gmail.com,,Yes,05/10/2019,1:15 PM,0:01
,,"New bulk edit modal (time trakcer, detailed report)",,james.white@gmail.com,,No,05/08/2019,2:40 PM,0:01
,,,,james.white@gmail.com,,Yes,04/23/2019,10:46 AM,0:01
MI-300 Web portal,Marvel Inc,Emails,,james.white@gmail.com,,Yes,04/02/2019,9:50 AM,1:30
MI-300 Web portal,Marvel Inc,Emails,,james.white@gmail.com,,Yes,04/02/2019,9:50 AM,0:00
MI-300 Web portal,Marvel Inc,Emails,,james.white@gmail.com,,Yes,04/02/2019,9:50 AM,2:30
MI-300 Web portal,Marvel Inc,Emails,,james.white@gmail.com,,Yes,04/02/2019,9:50 AM,1:00
MI-300 Web portal,Marvel Inc,Filing tax return,,james.white@gmail.com,,Yes,04/02/2019,9:50 AM,4:00
MI-300 Web portal,Marvel Inc,Filing tax return,,james.white@gmail.com,,Yes,04/02/2019,9:50 AM,1:00
CT-300 Web portal,California Tech,Implement new design,,james.white@gmail.com,,Yes,04/02/2019,9:50 AM,3:00
CT-300 Web portal,California Tech,Fixing bugs,,james.white@gmail.com,,Yes,03/19/2019,9:55 AM,1:00
CT-300 Web portal,California Tech,Fixing bugs,,james.white@gmail.com,,Yes,03/19/2019,9:55 AM,1:00
CT-300 Web portal,California Tech,Fixing bugs,,james.white@gmail.com,,Yes,03/19/2019,9:55 AM,1:00
CT-300 Web portal,California Tech,Fixing bugs,,james.white@gmail.com,,Yes,03/19/2019,9:55 AM,1:00
CT-300 Web portal,California Tech,Fixing bugs,,james.white@gmail.com,,Yes,03/19/2019,9:55 AM,1:00
CT-300 Web portal,California Tech,Fixing bugs,,james.white@gmail.com,,Yes,03/19/2019,9:55 AM,1:00
CT-300 Web portal,California Tech,Fixing bugs,,james.white@gmail.com,,Yes,03/19/2019,9:55 AM,2:00
CT-300 Web portal,California Tech,Database config,,james.white@gmail.com,,Yes,03/15/2019,1:39 PM,0:01
CT-300 Web portal,California Tech,Database config,,james.white@gmail.com,,Yes,03/15/2019,1:10 PM,0:29
CT-300 Web portal,California Tech,Troubleshooting,,james.white@gmail.com,,Yes,03/15/2019,12:00 PM,5:00
CT-300 Web portal,California Tech,Client meeting,,james.white@gmail.com,,No,03/13/2019,9:50 AM,4:59
CT-300 Web portal,California Tech,Client meeting,,james.white@gmail.com,,No,03/13/2019,9:50 AM,0:01
CT-300 Web portal,California Tech,Fix remote server problem,,james.white@gmail.com,,No,03/13/2019,9:32 AM,4:00
MI-300 Web portal,Marvel Inc,Bug fixing,,dale.the.knight@gmail.com,,Yes,03/05/2019,9:00 AM,4:00
,,,,dale.the.knight@gmail.com,,Yes,03/04/2019,9:00 AM,0:10
CT-300 Web portal,California Tech,Bug fixing,Development,dale.the.knight@gmail.com,,Yes,03/04/2019,9:00 AM,1:00
,,Lunch,,yvonne.gardner.ivy@gmail.com,,No,03/01/2019,9:00 AM,0:25
,,Break,,dale.the.knight@gmail.com,,No,03/01/2019,9:00 AM,0:30
CT-300 Web portal,California Tech,Database optimization,Development,dale.the.knight@gmail.com,,Yes,03/01/2019,9:00 AM,1:00
GS-100 Administration,Global Solutions,Customer support,,yvonne.gardner.ivy@gmail.com,,Yes,03/01/2019,9:00 AM,5:00
GS-100 Administration,Global Solutions,Tracking missing package #32321,,james.white@gmail.com,,Yes,02/28/2019,9:00 AM,2:00
CT-200 Banking app,California Tech,Solving customer issue #21212,,james.white@gmail.com,,Yes,02/28/2019,9:00 AM,1:00
,,Lunch,,james.white@gmail.com,,Yes,02/28/2019,9:00 AM,0:30
,,Lunch,,yvonne.gardner.ivy@gmail.com,,No,02/28/2019,9:00 AM,0:20
MI-300 Web portal,Marvel Inc,Emails,,dale.the.knight@gmail.com,,Yes,02/28/2019,9:00 AM,2:00
,,Break,,dale.the.knight@gmail.com,,No,02/28/2019,9:00 AM,0:20
CT-300 Web portal,California Tech,Database setup,Development,dale.the.knight@gmail.com,,Yes,02/28/2019,9:00 AM,3:00
MI-300 Web portal,Marvel Inc,Invoicing,,yvonne.gardner.ivy@gmail.com,,Yes,02/28/2019,9:00 AM,4:00
,,Lunch,,james.white@gmail.com,,Yes,02/27/2019,12:00 PM,0:30
MI-300 Web portal,Marvel Inc,Emails,,james.white@gmail.com,,Yes,02/27/2019,9:00 AM,8:00
CT-200 Banking app,California Tech,Paperwork,,james.white@gmail.com,,Yes,02/27/2019,9:00 AM,3:00
,,Coffee,,yvonne.gardner.ivy@gmail.com,,No,02/27/2019,9:00 AM,0:20
MI-300 Web portal,Marvel Inc,Filing tax return,,dale.the.knight@gmail.com,,Yes,02/27/2019,9:00 AM,3:00
,,Lunch,,dale.the.knight@gmail.com,,No,02/27/2019,9:00 AM,0:30
CT-300 Web portal,California Tech,Generating response call,Development,dale.the.knight@gmail.com,,Yes,02/27/2019,9:00 AM,4:00
CT-300 Web portal,California Tech,Spec writing,,yvonne.gardner.ivy@gmail.com,,Yes,02/27/2019,9:00 AM,7:00
MI-300 Web portal,Marvel Inc,Emails,,yvonne.gardner.ivy@gmail.com,,Yes,02/27/2019,9:00 AM,3:00
,,Lunch,,yvonne.gardner.ivy@gmail.com,,No,02/26/2019,9:00 AM,0:14
CT-300 Web portal,California Tech,Wireframing,,yvonne.gardner.ivy@gmail.com,,Yes,02/26/2019,9:00 AM,6:00
MI-300 Web portal,Marvel Inc,Research,,yvonne.gardner.ivy@gmail.com,,Yes,02/26/2019,9:00 AM,3:00
CT-200 Banking app,California Tech,Contacted accounting,,james.white@gmail.com,,Yes,02/26/2019,9:00 AM,4:00
,,Lunch,,james.white@gmail.com,,No,02/26/2019,9:00 AM,0:30
GS-100 Administration,Global Solutions,Delievered #2023,,james.white@gmail.com,,Yes,02/26/2019,9:00 AM,2:00
UE-100 Administration,United Express,On-field call,,james.white@gmail.com,,Yes,02/25/2019,9:00 AM,3:00
UE-100 Administration,United Express,On-field call,,james.white@gmail.com,,Yes,02/25/2019,9:00 AM,3:00
MI-300 Web portal,Marvel Inc,Emails,,james.white@gmail.com,,Yes,02/25/2019,9:00 AM,3:00
,,Lunch,,yvonne.gardner.ivy@gmail.com,,No,02/25/2019,9:00 AM,0:05
CT-300 Web portal,California Tech,Bug fixing,,yvonne.gardner.ivy@gmail.com,,Yes,02/25/2019,9:00 AM,1:00
MI-300 Web portal,Marvel Inc,Emails,,yvonne.gardner.ivy@gmail.com,,Yes,02/25/2019,9:00 AM,3:00
CT-200 Banking app,California Tech,Meetings,,james.white@gmail.com,,Yes,02/25/2019,9:00 AM,1:00
CT-300 Web portal,California Tech,Spec writing,Development,james.white@gmail.com,,Yes,02/25/2019,9:00 AM,1:00
,,Coffee,,james.white@gmail.com,,No,02/25/2019,9:00 AM,0:25
GS-100 Administration,Global Solutions,Feedback gathering,,james.white@gmail.com,,Yes,02/25/2019,9:00 AM,2:00