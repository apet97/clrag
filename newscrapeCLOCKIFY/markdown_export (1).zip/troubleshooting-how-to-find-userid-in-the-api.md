# troubleshooting-how-to-find-userid-in-the-api

> Source: https://clockify.me/help/troubleshooting/how-to-find-userid-in-the-api

How to find userID via API
1 min read
To retrieve the userID of a user, use the following endpoint:
Endpoint:
This endpoint returns only the currently logged-in user.
To get all users or a specific user’s ID, use the /v1/users
endpoint to fetch the full user list from the workspace.
Was this article helpful?
Thank you! If you’d like a member of our support team to respond to you, please drop us a note at support@clockify.me