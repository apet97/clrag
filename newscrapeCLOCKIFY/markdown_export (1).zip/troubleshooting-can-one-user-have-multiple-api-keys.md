# troubleshooting-can-one-user-have-multiple-api-keys

> Source: https://clockify.me/help/troubleshooting/can-one-user-have-multiple-api-keys

Can one user have multiple API keys?
1 min read
Yes, you can generate multiple API keys within one workspace.
To generate a new key, follow these steps:
- Navigate to Preferences
- Choose the Advanced tab
- Find the API key section and click on Generate in the upper right corner
- A window for generating the API key will appear
- Click on Generate
- Once the key is generated, close the window
Was this article helpful?
Thank you! If you’d like a member of our support team to respond to you, please drop us a note at support@clockify.me