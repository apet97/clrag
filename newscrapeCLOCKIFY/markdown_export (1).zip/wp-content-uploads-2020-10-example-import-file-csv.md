# wp-content-uploads-2020-10-example-import-file-csv

> Source: https://clockify.me/help/wp-content/uploads/2020/10/example_import_file.csv

Project,Client,Task,Tags
,Just Client,,
Project1,,,
Project2,,,
Project1 For Client1,Client1,,
Project2 For Client1,Client1,,
Project For Client2,Client2,,
Project With Task,,Task1,
Project With Task,,Task2,
Project For Client3 With Task,Client3,Task1,
,,,Tag A
,,,"Tag B, Tag C"