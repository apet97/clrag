# track-time-and-expenses-customize-kiosk

> Source: https://clockify.me/help/track-time-and-expenses/customize-kiosk

Customize kiosk
Choose how long a kiosk remains open and add your company logo to it.
Kiosk customization is a paid feature, that you can get by upgrading your account to Standard plan or higher.
Session duration #
Once you open and log into a kiosk as admin, it remains open for 24h (or until you close it), after which it needs to be relaunched again.
If you wish some kiosk to remain open longer or shorter so you don’t have to relaunch it each day:
- Go to Kiosks page
- Click three dots next to a kiosk
- Click Edit
- Click on number next to “Kiosk logs out after”
- Enter any number you wish in the popup field (in hours)
- Click Save
Branded kiosk #
Each kiosk shows Clockify logo on homescreen by default.
To show your company logo instead, go to workspace settings and upload company logo.
Once uploaded, your company logo will replace Clockify’s and be displayed on each kiosk.