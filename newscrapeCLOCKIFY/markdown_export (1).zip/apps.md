# apps

> Source: https://clockify.me/help/apps

Apps
- Getting Started
- Track Time & Expenses
- Reports
- Projects
- Administration
- Apps
- Integrations
-
Troubleshooting
- Team management issues
- API issues and tips
- System/platform limitations & configurations
- API integration & usage tips
- API & time entry management
- Working with data via API
- API response
- API key & authentication
- Account and workspace issues
- Approval issues
- Rates and invoicing issues
- Kiosk issues
- Other
- App issues
- Time off issues
- Integration issues
- Project, client, and task management issues
- Common issues
- Reporting issues
- Time tracking issues
- Generate reports
- Clockify integrations
- Billing and payment procedures